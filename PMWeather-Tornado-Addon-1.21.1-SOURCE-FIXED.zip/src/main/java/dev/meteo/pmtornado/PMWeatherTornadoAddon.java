package dev.meteo.pmtornado;

import dev.meteo.pmtornado.command.TornadoCommands;
import dev.meteo.pmtornado.compat.PMWeatherCompat;
import dev.meteo.pmtornado.registry.ModEntities;
import dev.meteo.pmtornado.registry.ModSounds;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.fml.common.Mod;

@Mod(PMWeatherTornadoAddon.MOD_ID)
public final class PMWeatherTornadoAddon {
    public static final String MOD_ID = "pmtornado";

    public PMWeatherTornadoAddon(IEventBus modBus) {
        ModEntities.ENTITY_TYPES.register(modBus);
        ModSounds.SOUND_EVENTS.register(modBus);

        NeoForge.EVENT_BUS.addListener(TornadoCommands::onRegisterCommands);
        // PMWeatherAPI emits VorticyEvent.New/Dead. Listening to the base Event
        // type avoids a hard link to PMWeatherCM1's private implementation.
        NeoForge.EVENT_BUS.addListener(PMWeatherCompat::onAnyEvent);
    }
}
