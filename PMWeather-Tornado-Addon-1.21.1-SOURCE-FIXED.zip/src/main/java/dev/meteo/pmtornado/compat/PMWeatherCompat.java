package dev.meteo.pmtornado.compat;

import dev.meteo.pmtornado.entity.TornadoEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.Event;
import net.neoforged.neoforge.server.ServerLifecycleHooks;

import java.lang.reflect.Method;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Optional PMWeatherAPI bridge. PMWeatherAPI 0.16.4.x exposes
 * VorticyEvent.New and VorticyEvent.Dead. The CM1 addon itself is closed-source,
 * so this bridge intentionally discovers event payload positions reflectively.
 */
public final class PMWeatherCompat {
    private static final Map<String, Long> LAST_SPAWN = new ConcurrentHashMap<>();
    private static final Set<String> LOGGED_EVENT_TYPES = ConcurrentHashMap.newKeySet();

    private PMWeatherCompat() { }

    public static void onAnyEvent(Event event) {
        String className = event.getClass().getName();
        String lower = className.toLowerCase(Locale.ROOT);
        if (!lower.contains("vorticy") && !lower.contains("vorticity")) return;
        if (booleanValue(event, "isClientSide", "isClient", "clientSide")) return;

        String simple = event.getClass().getSimpleName().toLowerCase(Locale.ROOT);
        boolean isDead = simple.contains("dead") || lower.contains("$dead");
        boolean isNew = simple.equals("new") || simple.contains("created") || lower.contains("$new");
        if (!isNew && !isDead) {
            // Some API versions use one event class plus a type getter.
            Object type = invokeFirst(event, "getType", "getEventType", "type");
            if (type != null) {
                String value = String.valueOf(type).toLowerCase(Locale.ROOT);
                isDead = value.contains("dead");
                isNew = value.contains("new") || value.contains("created");
            }
        }
        if (!isNew && !isDead) return;

        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;
        EventLocation location = extractLocation(event);
        ServerLevel level = location.level;
        Vec3 position = location.position;

        if (level == null && position != null) level = findNearestPlayerLevel(server, position);
        if (level == null) level = firstPlayerLevel(server);
        if (level == null) return;

        if (position == null) {
            ServerPlayer player = nearestPlayer(server, level, null);
            if (player == null) return;
            position = player.position();
            String eventKey = level.dimension().location() + ":fallback:" + player.getUUID();
            if (!isNew || recentlyHandled(eventKey)) return;
            TornadoEntity.spawn(level, position.x, position.z, 0.75F);
            logDetected(className, "no explicit position; used nearest player fallback");
            return;
        }

        String key = level.dimension().location() + ":" + Math.floor(position.x / 16.0) + ":" + Math.floor(position.z / 16.0);
        if (isNew) {
            if (recentlyHandled(key)) return;
            TornadoEntity.spawn(level, position.x, position.z, 0.82F);
            logDetected(className, "spawned tornado at " + position);
        } else {
            fadeNearest(level, position);
        }
    }

    private static boolean recentlyHandled(String key) {
        long now = System.currentTimeMillis();
        Long previous = LAST_SPAWN.put(key, now);
        return previous != null && now - previous < 45_000L;
    }

    private static void fadeNearest(ServerLevel level, Vec3 pos) {
        TornadoEntity closest = null;
        double best = 96.0 * 96.0;
        for (TornadoEntity tornado : level.getEntitiesOfClass(TornadoEntity.class,
                new net.minecraft.world.phys.AABB(pos.x - 96, level.getMinBuildHeight(), pos.z - 96,
                        pos.x + 96, level.getMaxBuildHeight(), pos.z + 96))) {
            double distance = tornado.position().distanceToSqr(pos);
            if (distance < best) { best = distance; closest = tornado; }
        }
        if (closest != null) closest.beginDissipating();
    }

    private static EventLocation extractLocation(Object root) {
        Set<Object> visited = Collections.newSetFromMap(new IdentityHashMap<>());
        ServerLevel level = findLevel(root, 0, visited);
        visited.clear();
        Vec3 pos = findPosition(root, 0, visited);
        return new EventLocation(level, pos);
    }

    private static ServerLevel findLevel(Object value, int depth, Set<Object> visited) {
        if (value == null || depth > 3 || !visited.add(value)) return null;
        if (value instanceof ServerLevel serverLevel) return serverLevel;
        if (value instanceof Level level && level instanceof ServerLevel serverLevel) return serverLevel;
        for (Method method : value.getClass().getMethods()) {
            if (method.getParameterCount() != 0 || method.getReturnType().isPrimitive()) continue;
            String name = method.getName().toLowerCase(Locale.ROOT);
            if (!(name.contains("level") || name.contains("world") || name.contains("weatherhandler") || name.contains("vort") || name.contains("storm"))) continue;
            try {
                Object result = method.invoke(value);
                ServerLevel found = findLevel(result, depth + 1, visited);
                if (found != null) return found;
            } catch (ReflectiveOperationException | RuntimeException ignored) { }
        }
        return null;
    }

    private static Vec3 findPosition(Object value, int depth, Set<Object> visited) {
        if (value == null || depth > 4 || !visited.add(value)) return null;
        if (value instanceof Vec3 vec3) return vec3;
        if (value instanceof BlockPos blockPos) return Vec3.atBottomCenterOf(blockPos);
        if (value instanceof ServerPlayer player) return player.position();
        for (Method method : value.getClass().getMethods()) {
            if (method.getParameterCount() != 0 || method.getReturnType().isPrimitive()) continue;
            String name = method.getName().toLowerCase(Locale.ROOT);
            if (name.equals("getposition") || name.equals("getpos") || name.equals("getcenter") || name.equals("getlocation") || name.equals("position") || name.equals("pos") || name.contains("vort") || name.contains("storm") || name.contains("origin")) {
                try {
                    Object result = method.invoke(value);
                    Vec3 found = findPosition(result, depth + 1, visited);
                    if (found != null) return found;
                } catch (ReflectiveOperationException | RuntimeException ignored) { }
            }
        }
        // Last-resort coordinate extraction for API payload classes exposing x/y/z getters.
        try {
            Object x = invokeFirst(value, "getX", "x");
            Object y = invokeFirst(value, "getY", "y");
            Object z = invokeFirst(value, "getZ", "z");
            if (x instanceof Number nx && y instanceof Number ny && z instanceof Number nz) {
                return new Vec3(nx.doubleValue(), ny.doubleValue(), nz.doubleValue());
            }
        } catch (RuntimeException ignored) { }
        return null;
    }

    private static Object invokeFirst(Object target, String... names) {
        for (String name : names) {
            try {
                Method method = target.getClass().getMethod(name);
                if (method.getParameterCount() == 0) return method.invoke(target);
            } catch (ReflectiveOperationException | RuntimeException ignored) { }
        }
        return null;
    }

    private static boolean booleanValue(Object target, String... names) {
        Object value = invokeFirst(target, names);
        return value instanceof Boolean b && b;
    }

    private static ServerLevel findNearestPlayerLevel(MinecraftServer server, Vec3 position) {
        ServerPlayer bestPlayer = nearestPlayer(server, null, position);
        return bestPlayer == null ? null : bestPlayer.serverLevel();
    }

    private static ServerPlayer nearestPlayer(MinecraftServer server, ServerLevel preferred, Vec3 pos) {
        ServerPlayer best = null;
        double bestDistance = Double.MAX_VALUE;
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (preferred != null && player.serverLevel() != preferred) continue;
            double distance = pos == null ? 0.0 : player.position().distanceToSqr(pos);
            if (distance < bestDistance) { bestDistance = distance; best = player; }
        }
        return best;
    }

    private static ServerLevel firstPlayerLevel(MinecraftServer server) {
        ServerPlayer player = server.getPlayerList().getPlayers().stream().findFirst().orElse(null);
        return player == null ? null : player.serverLevel();
    }

    private static void logDetected(String eventClass, String message) {
        if (LOGGED_EVENT_TYPES.add(eventClass)) {
            System.out.println("[PMWeather Tornado Addon] Detected PMWeatherAPI event " + eventClass + ": " + message);
        }
    }

    private record EventLocation(ServerLevel level, Vec3 position) { }
}
