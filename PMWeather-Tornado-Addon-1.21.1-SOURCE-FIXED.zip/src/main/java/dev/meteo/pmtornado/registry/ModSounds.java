package dev.meteo.pmtornado.registry;

import dev.meteo.pmtornado.PMWeatherTornadoAddon;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUND_EVENTS =
            DeferredRegister.create(Registries.SOUND_EVENT, PMWeatherTornadoAddon.MOD_ID);

    public static final DeferredHolder<SoundEvent, SoundEvent> TORNADO_WIND = SOUND_EVENTS.register("tornado_wind",
            () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(PMWeatherTornadoAddon.MOD_ID, "tornado_wind")));

    private ModSounds() { }
}
