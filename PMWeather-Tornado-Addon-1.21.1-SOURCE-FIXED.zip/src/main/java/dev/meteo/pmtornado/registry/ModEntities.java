package dev.meteo.pmtornado.registry;

import dev.meteo.pmtornado.PMWeatherTornadoAddon;
import dev.meteo.pmtornado.entity.TornadoEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(Registries.ENTITY_TYPE, PMWeatherTornadoAddon.MOD_ID);

    public static final DeferredHolder<EntityType<?>, EntityType<TornadoEntity>> TORNADO = ENTITY_TYPES.register("tornado",
            () -> EntityType.Builder.<TornadoEntity>of(TornadoEntity::new, MobCategory.MISC)
                    .sized(52.0F, 76.0F)
                    .clientTrackingRange(16)
                    .updateInterval(1)
                    .build("pmtornado:tornado"));

    private ModEntities() { }
}
