package dev.meteo.pmtornado.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.meteo.pmtornado.PMWeatherTornadoAddon;
import dev.meteo.pmtornado.entity.TornadoEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

public final class TornadoRenderer extends EntityRenderer<TornadoEntity> {
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
            PMWeatherTornadoAddon.MOD_ID, "textures/entity/tornado_vortex.png");
    private static final int RINGS = 64;
    private static final int SEGMENTS = 48;

    public TornadoRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0F;
    }

    @Override
    public void render(TornadoEntity entity, float entityYaw, float partialTick,
                       PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
        float growth = entity.getGrowthProgress(partialTick);
        if (growth <= 0.005F) return;

        float height = entity.getMaxHeight() * growth;
        float radiusScale = growth;
        float age = entity.tickCount + partialTick;
        PoseStack.Pose pose = poseStack.last();
        VertexConsumer consumer = buffers.getBuffer(RenderType.entityTranslucent(TEXTURE));

        for (int ring = 0; ring < RINGS; ring++) {
            float t0 = ring / (float) RINGS;
            float t1 = (ring + 1) / (float) RINGS;
            float y0 = t0 * height;
            float y1 = t1 * height;
            float r0 = radiusAt(t0, entity.getBaseRadius()) * radiusScale;
            float r1 = radiusAt(t1, entity.getBaseRadius()) * radiusScale;

            for (int segment = 0; segment < SEGMENTS; segment++) {
                float a0 = (float) (segment * Math.PI * 2.0 / SEGMENTS);
                float a1 = (float) ((segment + 1) * Math.PI * 2.0 / SEGMENTS);
                addQuad(consumer, pose, entity, age, t0, t1, y0, y1, r0, r1, a0, a1, packedLight, growth);
            }
        }

        super.render(entity, entityYaw, partialTick, poseStack, buffers, packedLight);
    }

    private static float radiusAt(float t, float maxRadius) {
        // Broad cloud-base attachment, a bulging mid-funnel and a narrower ground contact.
        float broadTop = 0.35F + 0.65F * smoothstep(t / 0.28F);
        float middleBulge = (float) Math.sin(Math.PI * t);
        float groundTaper = 0.28F + 0.72F * smoothstep(t / 0.18F);
        return maxRadius * (0.20F + 0.52F * broadTop + 0.32F * middleBulge) * groundTaper;
    }

    private static void addQuad(VertexConsumer out, PoseStack.Pose pose, TornadoEntity entity, float age,
                                float t0, float t1, float y0, float y1, float r0, float r1,
                                float a0, float a1, int light, float growth) {
        float spin0 = age * 0.038F + t0 * 3.4F;
        float spin1 = age * 0.038F + t1 * 3.4F;
        float[] p00 = point(r0, a0, spin0, t0, age, entity.getId());
        float[] p01 = point(r0, a1, spin0, t0, age, entity.getId());
        float[] p10 = point(r1, a0, spin1, t1, age, entity.getId());
        float[] p11 = point(r1, a1, spin1, t1, age, entity.getId());

        float fadeTop = 0.55F + 0.45F * (1.0F - smoothstep((t0 - 0.86F) / 0.14F));
        float fadeBase = 0.72F + 0.28F * smoothstep(t0 / 0.18F);
        float noise = 0.78F + 0.22F * (float) Math.sin(a0 * 7.0F + age * 0.075F + t0 * 19.0F);
        float alpha = Mth.clamp(0.16F + 0.31F * growth * fadeTop * fadeBase * noise, 0.0F, 0.52F);
        float shade = 0.48F + 0.08F * (float) Math.sin(a0 * 4.0F + t0 * 8.0F);
        float u0 = segmentU(a0, age);
        float u1 = segmentU(a1, age);
        float v0 = t0 * 2.8F - age * 0.008F;
        float v1 = t1 * 2.8F - age * 0.008F;

        put(out, pose, p00[0], y0, p00[1], shade, shade + 0.01F, shade + 0.03F, alpha, u0, v0, light, p00[2], p00[3]);
        put(out, pose, p01[0], y0, p01[1], shade, shade + 0.01F, shade + 0.03F, alpha, u1, v0, light, p01[2], p01[3]);
        put(out, pose, p11[0], y1, p11[1], shade, shade + 0.01F, shade + 0.03F, alpha * 0.95F, u1, v1, light, p11[2], p11[3]);
        put(out, pose, p10[0], y1, p10[1], shade, shade + 0.01F, shade + 0.03F, alpha * 0.95F, u0, v1, light, p10[2], p10[3]);
    }

    private static float[] point(float radius, float angle, float spin, float t, float age, int id) {
        float irregular = 1.0F
                + 0.075F * (float) Math.sin(angle * 5.0F + spin * 1.6F + id)
                + 0.035F * (float) Math.sin(angle * 11.0F - t * 13.0F + age * 0.028F)
                + 0.025F * (float) Math.sin(angle * 19.0F + t * 7.0F - age * 0.045F);
        float a = angle + spin;
        float x = (float) Math.cos(a) * radius * irregular;
        float z = (float) Math.sin(a) * radius * irregular;
        float nx = (float) Math.cos(a);
        float nz = (float) Math.sin(a);
        return new float[]{x, z, nx, nz};
    }

    private static float segmentU(float angle, float age) {
        return (float) (angle / (Math.PI * 2.0) * 3.0) + age * 0.0028F;
    }

    private static void put(VertexConsumer out, PoseStack.Pose pose, float x, float y, float z,
                            float red, float green, float blue, float alpha,
                            float u, float v, int light, float nx, float nz) {
        out.addVertex(pose, x, y, z)
                .setColor(red, green, blue, alpha)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(light)
                .setNormal(pose, nx, 0.06F, nz);
    }

    private static float smoothstep(float value) {
        float t = Mth.clamp(value, 0.0F, 1.0F);
        return t * t * (3.0F - 2.0F * t);
    }

    @Override
    public ResourceLocation getTextureLocation(TornadoEntity entity) {
        return TEXTURE;
    }
}
